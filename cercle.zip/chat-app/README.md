# Cercle : réseau social Next.js + Supabase

1. Supabase → SQL Editor → collez et exécutez `supabase/schema.sql`
2. (Dev) Authentication → Email → désactivez "Confirm email"
3. `.env.local` avec l'URL et la clé anon du projet
4. `npm install && npm run dev` → http://localhost:3000
